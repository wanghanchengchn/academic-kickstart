---
title: 关于解决k中心聚类的方法的调查
event: 本科毕业设计
# event_url: https://example.org

# location: Source Themes HQ
# address:
#   street: 450 Serra Mall
#   city: Stanford
#   region: CA
#   postcode: '94305'
#   country: United States

summary: 关于解决k中心聚类的方法的调查
abstract: "k中心问题在过去的四十年中不断发展，其研究思路也随着数据的急剧增长不断变化。本文整理了近四十年来关于k中心问题的研究成果，分类比较了MapReduce和Streaming场景下k中心算法之间的引证关系与改进，以期对了解k中心聚类发展脉络有所助益。"


# Talk start and end times.
#   End time can optionally be hidden by prefixing the line with `#`.
# date: "2019-11-10T15:00:00Z"
date: "2020-02-28T15:00:00Z"
# date_end: "2019-11-10T15:30:00Z"
all_day: false

# Schedule page publish date (NOT talk date).
publishDate: "2020-02-28T15:00:00Z"

authors: [admin]
tags: ["本科毕业设计"]

# Is this a featured talk? (true/false)
featured: false

image:
  caption: ''
  focal_point: Right

links:
# - icon: twitter
#  icon_pack: fab
#  name: Follow
#  url: https://twitter.com/georgecushen
url_code: ""
url_pdf: "pdf/9 - 关于解决k中心聚类的方法的调查.pdf"
url_slides: ""
url_video: ""

# Markdown Slides (optional).
#   Associate this talk with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides = "example-slides"` references `content/slides/example-slides.md`.
#   Otherwise, set `slides = ""`.
# slides: example

# Projects (optional).
#   Associate this post with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `projects = ["internal-project"]` references `content/project/deep-learning/index.md`.
#   Otherwise, set `projects = []`.
# projects:
# - internal-project

# Enable math on this page?
math: true
---

<!-- {{% alert note %}}
Click on the **Slides** button above to view the built-in slides feature.
{{% /alert %}}
 -->

<!-- Slides can be added in a few ways:

- **Create** slides using Academic's [*Slides*](https://sourcethemes.com/academic/docs/managing-content/#create-slides) feature and link using `slides` parameter in the front matter of the talk file
- **Upload** an existing slide deck to `static/` and link using `url_slides` parameter in the front matter of the talk file
- **Embed** your slides (e.g. Google Slides) or presentation video on this page using [shortcodes](https://sourcethemes.com/academic/docs/writing-markdown-latex/).

Further talk details can easily be added to this page using *Markdown* and $\rm \LaTeX$ math code.
 -->